import pygame
import game.game as game

if __name__ == "__main__":
    game = game.Game()
    game.run()